# 개발자 정보 공유 서비스

# 관리자 계정

# 역할 분배

수정님 : 요구사항 정리

태균님 : accounts/views.py index 작성

진아님 : 
- CUSTOM USER 모델 작성 accounts/models.py
- Post 모델 작성 accounts/models.py
- 회원가입 페이지 작성
-edit,update완료